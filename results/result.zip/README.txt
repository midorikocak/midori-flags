Files are located at results folder.
